use bevy::prelude::*;

use crate::state::{Life, Run, Toast};

pub const COUNT: usize = 5;

/// Cartoon stand-ins, not real drugs. Each one bends the rules differently.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Substance {
    GoGoPowder,
    BlueSlurp,
    GiggleCaps,
    MoonChew,
    CrunchRock,
}

impl Substance {
    pub const ALL: [Substance; COUNT] = [
        Substance::GoGoPowder,
        Substance::BlueSlurp,
        Substance::GiggleCaps,
        Substance::MoonChew,
        Substance::CrunchRock,
    ];

    pub fn idx(self) -> usize {
        self as usize
    }

    pub fn name(self) -> &'static str {
        match self {
            Substance::GoGoPowder => "Go-Go Powder",
            Substance::BlueSlurp => "Blue Slurp",
            Substance::GiggleCaps => "Giggle Caps",
            Substance::MoonChew => "Moon Chew",
            Substance::CrunchRock => "Crunch Rock",
        }
    }

    pub fn blurb(self) -> &'static str {
        match self {
            Substance::GoGoPowder => "faster, twitchier, camera can't sit still",
            Substance::BlueSlurp => "slow and floaty, but your clock barely ticks",
            Substance::GiggleCaps => "colors melt, junk starts dancing, bonus points",
            Substance::MoonChew => "moon gravity, go find that rooftop stash",
            Substance::CrunchRock => "tackles hit like trucks, double points",
        }
    }

    /// RGB used for the pickup and its beacon.
    pub fn color(self) -> (f32, f32, f32) {
        match self {
            Substance::GoGoPowder => (0.95, 0.95, 0.85),
            Substance::BlueSlurp => (0.2, 0.5, 1.0),
            Substance::GiggleCaps => (0.9, 0.3, 0.9),
            Substance::MoonChew => (0.4, 1.0, 0.7),
            Substance::CrunchRock => (1.0, 0.55, 0.15),
        }
    }

    /// Seconds of life restored (before tolerance).
    pub fn life_gain(self) -> f32 {
        match self {
            Substance::GoGoPowder => 12.0,
            Substance::BlueSlurp => 10.0,
            Substance::GiggleCaps => 11.0,
            Substance::MoonChew => 9.0,
            Substance::CrunchRock => 10.0,
        }
    }

    /// Seconds the effect lasts.
    pub fn duration(self) -> f32 {
        match self {
            Substance::GoGoPowder => 10.0,
            Substance::BlueSlurp => 14.0,
            Substance::GiggleCaps => 15.0,
            Substance::MoonChew => 12.0,
            Substance::CrunchRock => 10.0,
        }
    }
}

/// Active effect timers, tolerance, and comedown.
#[derive(Resource, Default)]
pub struct Effects {
    pub timers: [f32; COUNT],
    /// Recent-use counts. Each use cuts the next life gain; decays over time.
    pub uses: [f32; COUNT],
    pub crash: f32,
}

impl Effects {
    pub fn active(&self, s: Substance) -> bool {
        self.timers[s.idx()] > 0.0
    }
}

/// Everything gameplay systems need to know about the current "high".
#[derive(Resource, Clone)]
pub struct Mods {
    pub speed: f32,
    pub gravity: f32,
    pub jump: f32,
    pub tackle: f32,
    pub drain: f32,
    pub score: f32,
    pub shake: f32,
    pub fov: f32,
    pub hallu: bool,
    pub active: usize,
}

impl Default for Mods {
    fn default() -> Self {
        Self {
            speed: 1.0,
            gravity: 1.0,
            jump: 1.0,
            tackle: 1.0,
            drain: 1.0,
            score: 1.0,
            shake: 0.0,
            fov: 0.0,
            hallu: false,
            active: 0,
        }
    }
}

impl Mods {
    pub fn from_effects(e: &Effects) -> Self {
        let mut m = Mods::default();

        if e.active(Substance::GoGoPowder) {
            m.speed *= 1.7;
            m.shake += 0.04;
            m.fov += 0.12;
            m.active += 1;
        }
        if e.active(Substance::BlueSlurp) {
            m.speed *= 0.6;
            m.gravity *= 0.5;
            m.drain *= 0.35;
            m.fov -= 0.12;
            m.active += 1;
        }
        if e.active(Substance::GiggleCaps) {
            m.hallu = true;
            m.score *= 1.5;
            m.active += 1;
        }
        if e.active(Substance::MoonChew) {
            m.gravity *= 0.25;
            m.jump *= 1.15;
            m.fov += 0.08;
            m.active += 1;
        }
        if e.active(Substance::CrunchRock) {
            m.tackle *= 3.0;
            m.score *= 2.0;
            m.shake += 0.02;
            m.active += 1;
        }

        // The comedown: slower, burns life faster.
        if e.crash > 0.0 {
            m.speed *= 0.55;
            m.drain *= 1.5;
            m.shake += 0.015;
            m.fov -= 0.1;
        }

        // Mixing three or more at once overloads you.
        if m.active >= 3 {
            m.drain *= 1.6;
            m.shake += 0.02;
        }
        m
    }
}

pub fn tick_effects(
    time: Res<Time>,
    run: Res<Run>,
    mut effects: ResMut<Effects>,
    mut mods: ResMut<Mods>,
    mut toast: ResMut<Toast>,
) {
    let dt = time.delta_secs();
    if run.alive {
        for s in Substance::ALL {
            let i = s.idx();
            if effects.timers[i] > 0.0 {
                effects.timers[i] -= dt;
                if effects.timers[i] <= 0.0 {
                    effects.timers[i] = 0.0;
                    effects.crash = (effects.crash + 3.0).min(8.0);
                    toast.say(format!("{} wore off. Comedown incoming...", s.name()));
                }
            }
            // Tolerance recovers: one "use" worth every 25 seconds.
            effects.uses[i] = (effects.uses[i] - dt / 25.0).max(0.0);
        }
        effects.crash = (effects.crash - dt).max(0.0);
    }
    toast.timer = (toast.timer - dt).max(0.0);
    *mods = Mods::from_effects(&effects);
}

pub fn life_drain(
    time: Res<Time>,
    mods: Res<Mods>,
    mut life: ResMut<Life>,
    mut run: ResMut<Run>,
) {
    if !run.alive {
        return;
    }
    let dt = time.delta_secs();
    run.time += dt;
    run.combo_timer = (run.combo_timer - dt).max(0.0);
    if run.combo_timer == 0.0 {
        run.combo = 0;
    }

    life.left -= dt * mods.drain;
    if life.left <= 0.0 {
        life.left = 0.0;
        run.alive = false;
        run.best = run.best.max(run.score);
    }
}
