use bevy::prelude::*;

/// The clock that is always running out.
#[derive(Resource)]
pub struct Life {
    pub left: f32,
    pub max: f32,
}

impl Default for Life {
    fn default() -> Self {
        Self { left: 40.0, max: 90.0 }
    }
}

/// Per-run stats.
#[derive(Resource)]
pub struct Run {
    pub alive: bool,
    pub time: f32,
    pub score: f32,
    pub best: f32,
    pub combo: u32,
    pub combo_timer: f32,
}

impl Default for Run {
    fn default() -> Self {
        Self {
            alive: true,
            time: 0.0,
            score: 0.0,
            best: 0.0,
            combo: 0,
            combo_timer: 0.0,
        }
    }
}

impl Run {
    /// Award chaos points. Chained hits within 3 seconds build a combo.
    pub fn chaos(&mut self, base: f32, mult: f32) -> f32 {
        self.combo = (self.combo + 1).min(25);
        self.combo_timer = 3.0;
        let pts = base * (1.0 + self.combo as f32 / 5.0) * mult;
        self.score += pts;
        pts
    }
}

/// One-line message shown near the bottom of the screen.
#[derive(Resource, Default)]
pub struct Toast {
    pub text: String,
    pub timer: f32,
}

impl Toast {
    pub fn say(&mut self, s: impl Into<String>) {
        self.text = s.into();
        self.timer = 4.5;
    }
}
