use std::f32::consts::{FRAC_PI_2, PI, TAU};

use bevy::input::mouse::MouseMotion;
use bevy::prelude::*;
use bevy::window::{CursorGrabMode, PrimaryWindow};

use crate::state::Run;
use crate::substances::Mods;
use crate::util::{resolve_sphere_aabb, Rng, MAP_HALF};
use crate::world::Collider;

pub const PLAYER_R: f32 = 0.6;

#[derive(Component)]
pub struct Player {
    pub vel: Vec3,
    pub on_ground: bool,
    pub heading: f32,
    pub facing: Vec3,
    pub tackle: f32,
    pub tackle_cd: f32,
    pub flop: f32,
}

impl Default for Player {
    fn default() -> Self {
        Self {
            vel: Vec3::ZERO,
            on_ground: false,
            heading: 0.0,
            facing: Vec3::NEG_Z,
            tackle: 0.0,
            tackle_cd: 0.0,
            flop: 0.0,
        }
    }
}

#[derive(Component)]
pub struct Arm {
    pub side: f32,
}

#[derive(Component)]
pub struct MainCam;

#[derive(Resource)]
pub struct CamRig {
    pub yaw: f32,
    pub pitch: f32,
    pub dist: f32,
}

impl Default for CamRig {
    fn default() -> Self {
        Self {
            yaw: 0.0,
            pitch: 0.35,
            dist: 9.0,
        }
    }
}

pub fn spawn_player(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
) {
    let skin = materials.add(Color::srgb(0.86, 0.72, 0.62));
    let hoodie = materials.add(Color::srgb(0.25, 0.28, 0.32));
    let eye_white = materials.add(StandardMaterial {
        base_color: Color::WHITE,
        emissive: LinearRgba::rgb(0.6, 0.6, 0.6),
        ..default()
    });
    let pupil = materials.add(Color::BLACK);

    commands
        .spawn((
            Transform::from_xyz(2.0, PLAYER_R, 2.0),
            Visibility::default(),
            Player::default(),
        ))
        .with_children(|p| {
            // Torso
            p.spawn((
                Mesh3d(meshes.add(Capsule3d::new(0.36, 0.55))),
                MeshMaterial3d(hoodie.clone()),
                Transform::from_xyz(0.0, 0.05, 0.0),
            ));

            // Head with wide, unblinking eyes (they look toward -Z)
            p.spawn((
                Mesh3d(meshes.add(Sphere::new(0.3))),
                MeshMaterial3d(skin.clone()),
                Transform::from_xyz(0.0, 0.95, 0.0),
            ))
            .with_children(|h| {
                for s in [-1.0f32, 1.0] {
                    h.spawn((
                        Mesh3d(meshes.add(Sphere::new(0.1))),
                        MeshMaterial3d(eye_white.clone()),
                        Transform::from_xyz(0.11 * s, 0.05, -0.24),
                    ))
                    .with_children(|e| {
                        e.spawn((
                            Mesh3d(meshes.add(Sphere::new(0.06))),
                            MeshMaterial3d(pupil.clone()),
                            Transform::from_xyz(0.0, 0.0, -0.06),
                        ));
                    });
                }
            });

            // Arms hang from shoulder pivots so they can flail
            for s in [-1.0f32, 1.0] {
                p.spawn((
                    Transform::from_xyz(0.5 * s, 0.55, 0.0),
                    Visibility::default(),
                    Arm { side: s },
                ))
                .with_children(|a| {
                    a.spawn((
                        Mesh3d(meshes.add(Capsule3d::new(0.1, 0.45))),
                        MeshMaterial3d(skin.clone()),
                        Transform::from_xyz(0.0, -0.35, 0.0),
                    ));
                });
            }
        });
}

pub fn spawn_camera(mut commands: Commands) {
    commands.spawn((
        Camera3d::default(),
        Projection::Perspective(PerspectiveProjection {
            fov: 1.15,
            ..default()
        }),
        Transform::from_xyz(2.0, 6.0, 11.0).looking_at(Vec3::new(2.0, 1.0, 2.0), Vec3::Y),
        MainCam,
    ));
}

pub fn grab_cursor(mut windows: Query<&mut Window, With<PrimaryWindow>>) {
    if let Ok(mut w) = windows.get_single_mut() {
        // If Locked is unsupported on your platform, try CursorGrabMode::Confined.
        w.cursor_options.grab_mode = CursorGrabMode::Locked;
        w.cursor_options.visible = false;
    }
}

/// Esc releases the mouse, clicking the window grabs it again.
pub fn toggle_cursor(
    keys: Res<ButtonInput<KeyCode>>,
    mouse: Res<ButtonInput<MouseButton>>,
    mut windows: Query<&mut Window, With<PrimaryWindow>>,
) {
    let Ok(mut w) = windows.get_single_mut() else {
        return;
    };
    if keys.just_pressed(KeyCode::Escape) {
        w.cursor_options.grab_mode = CursorGrabMode::None;
        w.cursor_options.visible = true;
    } else if mouse.just_pressed(MouseButton::Left)
        && w.cursor_options.grab_mode == CursorGrabMode::None
    {
        w.cursor_options.grab_mode = CursorGrabMode::Locked;
        w.cursor_options.visible = false;
    }
}

pub fn player_control(
    time: Res<Time>,
    keys: Res<ButtonInput<KeyCode>>,
    mouse: Res<ButtonInput<MouseButton>>,
    rig: Res<CamRig>,
    mods: Res<Mods>,
    run: Res<Run>,
    mut q: Query<(&mut Transform, &mut Player)>,
    statics: Query<(&Transform, &Collider), Without<Player>>,
) {
    let dt = time.delta_secs().min(0.05);
    let Ok((mut tf, mut p)) = q.get_single_mut() else {
        return;
    };

    p.tackle = (p.tackle - dt).max(0.0);
    p.tackle_cd = (p.tackle_cd - dt).max(0.0);
    p.flop = (p.flop - dt).max(0.0);

    let controllable = run.alive && p.flop <= 0.0;
    let yaw_q = Quat::from_rotation_y(rig.yaw);

    let mut wish = Vec3::ZERO;
    if controllable {
        if keys.pressed(KeyCode::KeyW) {
            wish += yaw_q * Vec3::NEG_Z;
        }
        if keys.pressed(KeyCode::KeyS) {
            wish += yaw_q * Vec3::Z;
        }
        if keys.pressed(KeyCode::KeyA) {
            wish -= yaw_q * Vec3::X;
        }
        if keys.pressed(KeyCode::KeyD) {
            wish += yaw_q * Vec3::X;
        }
    }
    let wish = wish.normalize_or_zero();

    if controllable {
        if keys.just_pressed(KeyCode::Space) && p.on_ground {
            p.vel.y = 9.0 * mods.jump;
            p.on_ground = false;
        }
        let tackle_pressed =
            mouse.just_pressed(MouseButton::Left) || keys.just_pressed(KeyCode::KeyF);
        if tackle_pressed && p.tackle_cd <= 0.0 {
            let dir = if wish != Vec3::ZERO { wish } else { p.facing };
            p.facing = dir;
            p.vel.x = dir.x * 19.0;
            p.vel.z = dir.z * 19.0;
            p.vel.y = p.vel.y.max(3.0);
            p.tackle = 0.45;
            p.tackle_cd = 0.9;
            p.on_ground = false;
        }
    }
    if run.alive && p.flop <= 0.0 && keys.just_pressed(KeyCode::KeyQ) {
        p.flop = 1.6;
        p.vel.y = p.vel.y.max(5.0);
    }

    // Horizontal movement
    let sprint = if keys.pressed(KeyCode::ShiftLeft) { 1.45 } else { 1.0 };
    let speed = 8.0 * mods.speed * sprint;
    if p.tackle <= 0.0 {
        let target = wish * speed;
        let accel = if !run.alive || p.flop > 0.0 {
            1.5
        } else if p.on_ground {
            14.0
        } else {
            4.0
        };
        let k = 1.0 - (-accel * dt).exp();
        p.vel.x += (target.x - p.vel.x) * k;
        p.vel.z += (target.z - p.vel.z) * k;
    }
    if wish != Vec3::ZERO {
        p.facing = wish;
    }

    // Smooth turning toward the facing direction
    let target_heading = (-p.facing.x).atan2(-p.facing.z);
    let mut diff = target_heading - p.heading;
    diff = (diff + PI).rem_euclid(TAU) - PI;
    p.heading += diff * (1.0 - (-14.0 * dt).exp());

    // Gravity and integration
    p.vel.y -= 22.0 * mods.gravity * dt;
    let mut pos = tf.translation + p.vel * dt;
    let mut vel = p.vel;
    let mut grounded = false;

    for (stf, col) in &statics {
        if let Some(n) =
            resolve_sphere_aabb(&mut pos, &mut vel, PLAYER_R, stf.translation, col.half, 0.1)
        {
            if n.y > 0.6 {
                grounded = true;
            }
        }
    }

    if pos.y < PLAYER_R {
        pos.y = PLAYER_R;
        if vel.y < 0.0 {
            vel.y = 0.0;
        }
        grounded = true;
    }
    if pos.x.abs() > MAP_HALF {
        pos.x = pos.x.clamp(-MAP_HALF, MAP_HALF);
        vel.x = 0.0;
    }
    if pos.z.abs() > MAP_HALF {
        pos.z = pos.z.clamp(-MAP_HALF, MAP_HALF);
        vel.z = 0.0;
    }

    p.vel = vel;
    p.on_ground = grounded;

    // Pose: flop lies flat, tackle leans forward
    tf.translation = pos;
    let lie = ((1.6 - p.flop) / 0.15).min(p.flop / 0.3).clamp(0.0, 1.0);
    let lean = if p.tackle > 0.0 { 0.45 } else { 0.0 };
    let pose = lie.max(lean);
    tf.rotation = Quat::from_rotation_y(p.heading) * Quat::from_rotation_x(-FRAC_PI_2 * pose);
}

/// Arms flail faster the faster (and more wired) you are.
pub fn animate_arms(
    time: Res<Time>,
    mods: Res<Mods>,
    players: Query<&Player>,
    mut arms: Query<(&mut Transform, &Arm)>,
) {
    let Ok(p) = players.get_single() else {
        return;
    };
    let speed = Vec2::new(p.vel.x, p.vel.z).length();
    let t = time.elapsed_secs();
    let freq = 6.0 + speed * 0.9 + mods.shake * 200.0;
    let amp = (0.3 + (speed / 8.0).min(1.5) * 0.6 + mods.shake * 10.0).min(1.6);
    for (mut tf, arm) in &mut arms {
        tf.rotation = Quat::from_rotation_x((t * freq * arm.side).sin() * amp);
    }
}

pub fn camera_follow(
    time: Res<Time>,
    mut motion: EventReader<MouseMotion>,
    mut rig: ResMut<CamRig>,
    mods: Res<Mods>,
    mut rng: ResMut<Rng>,
    player: Query<&Transform, (With<Player>, Without<MainCam>)>,
    mut cam: Query<(&mut Transform, &mut Projection), (With<MainCam>, Without<Player>)>,
) {
    let dt = time.delta_secs().min(0.05);
    for ev in motion.read() {
        rig.yaw -= ev.delta.x * 0.0028;
        rig.pitch = (rig.pitch + ev.delta.y * 0.0028).clamp(-0.15, 1.35);
    }

    let Ok(ptf) = player.get_single() else {
        return;
    };
    let Ok((mut ctf, mut proj)) = cam.get_single_mut() else {
        return;
    };

    let target = ptf.translation + Vec3::Y * 0.9;
    let offset = Quat::from_rotation_y(rig.yaw)
        * Quat::from_rotation_x(-rig.pitch)
        * Vec3::new(0.0, 0.0, rig.dist);
    let mut desired = target + offset;
    desired.y = desired.y.max(0.4);

    let k = 1.0 - (-12.0 * dt).exp();
    ctf.translation = ctf.translation.lerp(desired, k);
    if mods.shake > 0.0 {
        ctf.translation += Vec3::new(rng.signed(), rng.signed(), rng.signed()) * mods.shake;
    }
    ctf.look_at(target, Vec3::Y);

    // FOV breathes with the current high
    let t = time.elapsed_secs();
    let mut target_fov = 1.15 + mods.fov;
    if mods.hallu {
        target_fov += (t * 1.4).sin() * 0.2;
    }
    if let Projection::Perspective(p) = &mut *proj {
        p.fov += (target_fov - p.fov) * (1.0 - (-6.0 * dt).exp());
    }
}
