use bevy::prelude::*;

use crate::player::Player;
use crate::state::{Life, Run, Toast};
use crate::substances::{Effects, Substance, COUNT};
use crate::util::{free_spot, Rng};
use crate::world::Collider;

#[derive(Component)]
pub struct Pickup {
    pub kind: Substance,
    pub base_y: f32,
    pub phase: f32,
    pub ttl: f32,
}

/// Shared meshes and materials so spawning pickups is cheap.
#[derive(Resource)]
pub struct PickupAssets {
    pub meshes: Vec<Handle<Mesh>>,
    pub mats: Vec<Handle<StandardMaterial>>,
    pub beacon_mesh: Handle<Mesh>,
    pub beacon_mats: Vec<Handle<StandardMaterial>>,
}

impl PickupAssets {
    pub fn create(meshes: &mut Assets<Mesh>, materials: &mut Assets<StandardMaterial>) -> Self {
        // One shape per substance, in Substance::ALL order.
        let shapes = vec![
            meshes.add(Cuboid::new(0.6, 0.12, 0.6)),
            meshes.add(Cylinder::new(0.2, 0.7)),
            meshes.add(Sphere::new(0.4)),
            meshes.add(Cuboid::new(0.7, 0.25, 0.4)),
            meshes.add(Cuboid::new(0.5, 0.5, 0.5)),
        ];

        let mut mats = Vec::new();
        let mut beacon_mats = Vec::new();
        for s in Substance::ALL {
            let (r, g, b) = s.color();
            mats.push(materials.add(StandardMaterial {
                base_color: Color::srgb(r, g, b),
                emissive: LinearRgba::rgb(r * 2.5, g * 2.5, b * 2.5),
                ..default()
            }));
            beacon_mats.push(materials.add(StandardMaterial {
                base_color: Color::srgba(r, g, b, 0.18),
                emissive: LinearRgba::rgb(r, g, b),
                alpha_mode: AlphaMode::Blend,
                unlit: true,
                cull_mode: None,
                ..default()
            }));
        }

        Self {
            meshes: shapes,
            mats,
            beacon_mesh: meshes.add(Cylinder::new(0.12, 16.0)),
            beacon_mats,
        }
    }
}

pub fn spawn_pickup(commands: &mut Commands, assets: &PickupAssets, kind: Substance, pos: Vec3) {
    let i = kind.idx();
    let scale = if kind == Substance::GiggleCaps {
        Vec3::new(1.2, 0.8, 1.2)
    } else {
        Vec3::ONE
    };
    commands
        .spawn((
            Mesh3d(assets.meshes[i].clone()),
            MeshMaterial3d(assets.mats[i].clone()),
            Transform::from_translation(pos).with_scale(scale),
            Pickup {
                kind,
                base_y: pos.y,
                phase: pos.x + pos.z,
                ttl: 50.0,
            },
        ))
        .with_children(|c| {
            // A faint light beam so stashes can be spotted across the map.
            c.spawn((
                Mesh3d(assets.beacon_mesh.clone()),
                MeshMaterial3d(assets.beacon_mats[i].clone()),
                Transform::from_xyz(0.0, 8.0, 0.0),
            ));
        });
}

fn consume(
    kind: Substance,
    effects: &mut Effects,
    life: &mut Life,
    run: &mut Run,
    toast: &mut Toast,
) {
    let i = kind.idx();

    // Tolerance: repeating the same thing pays less each time.
    let tolerance = 0.65f32.powf(effects.uses[i]);
    let gain = (kind.life_gain() * tolerance).max(2.0);

    life.left = (life.left + gain).min(life.max);
    effects.timers[i] = kind.duration();
    effects.uses[i] += 1.0;
    effects.crash = 0.0; // chasing the next one skips the comedown
    run.score += 20.0;

    let note = if tolerance < 0.5 {
        " - your body is getting used to it"
    } else {
        ""
    };
    toast.say(format!(
        "{}  +{:.0}s  {}{}",
        kind.name(),
        gain,
        kind.blurb(),
        note
    ));
}

pub fn pickups_system(
    time: Res<Time>,
    mut commands: Commands,
    player: Query<&Transform, (With<Player>, Without<Pickup>)>,
    mut pickups: Query<(Entity, &mut Transform, &mut Pickup), Without<Player>>,
    mut effects: ResMut<Effects>,
    mut life: ResMut<Life>,
    mut run: ResMut<Run>,
    mut toast: ResMut<Toast>,
) {
    let dt = time.delta_secs();
    let t = time.elapsed_secs();
    let Ok(ptf) = player.get_single() else {
        return;
    };

    for (e, mut tf, mut pk) in &mut pickups {
        pk.ttl -= dt;
        if pk.ttl <= 0.0 {
            commands.entity(e).despawn_recursive();
            continue;
        }

        tf.rotate_y(dt * 1.8);
        tf.translation.y = pk.base_y + (t * 2.0 + pk.phase).sin() * 0.15;

        if run.alive && tf.translation.distance(ptf.translation) < 1.6 {
            consume(pk.kind, &mut effects, &mut life, &mut run, &mut toast);
            commands.entity(e).despawn_recursive();
        }
    }
}

pub fn pickup_spawner(
    time: Res<Time>,
    mut commands: Commands,
    assets: Res<PickupAssets>,
    mut rng: ResMut<Rng>,
    run: Res<Run>,
    pickups: Query<&Pickup>,
    statics: Query<(&Transform, &Collider)>,
    mut cooldown: Local<f32>,
) {
    if !run.alive {
        return;
    }
    *cooldown -= time.delta_secs();
    let count = pickups.iter().count();
    if *cooldown > 0.0 || count >= 6 {
        return;
    }
    *cooldown = if count < 3 { 0.1 } else { 1.5 };

    let obstacles: Vec<(Vec3, Vec3)> = statics
        .iter()
        .map(|(t, c)| (t.translation, c.half))
        .collect();
    let kind = Substance::ALL[rng.index(COUNT)];

    // Sometimes the stash is on a low rooftop. Moon Chew gets you up there.
    let roofs: Vec<&(Vec3, Vec3)> = obstacles
        .iter()
        .filter(|o| o.1.x > 2.5 && o.1.y * 2.0 <= 7.0)
        .collect();

    let pos = if !roofs.is_empty() && rng.chance(0.22) {
        let r = roofs[rng.index(roofs.len())];
        Vec3::new(r.0.x, r.0.y + r.1.y + 1.0, r.0.z)
    } else {
        let p = free_spot(&mut rng, &obstacles, 1.2);
        Vec3::new(p.x, 0.9, p.y)
    };

    spawn_pickup(&mut commands, &assets, kind, pos);
}
