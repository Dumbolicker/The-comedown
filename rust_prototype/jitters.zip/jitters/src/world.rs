use bevy::prelude::*;

use crate::pickups::PickupAssets;
use crate::player::{Player, PLAYER_R};
use crate::state::Run;
use crate::substances::Mods;
use crate::util::{free_spot, resolve_sphere_aabb, sky, Rng, MAP_HALF};

/// Static axis-aligned box the player and props bump into.
#[derive(Component)]
pub struct Collider {
    pub half: Vec3,
}

/// Loose junk that gets launched around.
#[derive(Component)]
pub struct Prop {
    pub vel: Vec3,
    pub ang: Vec3,
    pub radius: f32,
    pub mass: f32,
    pub cooldown: f32,
    pub hue: f32,
    pub base: Color,
}

pub fn setup_world(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
    mut rng: ResMut<Rng>,
) {
    // Sun
    commands.spawn((
        DirectionalLight {
            illuminance: 11_000.0,
            shadows_enabled: true,
            ..default()
        },
        Transform::from_xyz(40.0, 60.0, 25.0).looking_at(Vec3::ZERO, Vec3::Y),
    ));

    // Ground
    let span = MAP_HALF * 2.0 + 20.0;
    commands.spawn((
        Mesh3d(meshes.add(Plane3d::default().mesh().size(span, span))),
        MeshMaterial3d(materials.add(StandardMaterial {
            base_color: Color::srgb(0.33, 0.35, 0.28),
            perceptual_roughness: 1.0,
            ..default()
        })),
    ));

    // Roads (a cross through the middle)
    let road = materials.add(StandardMaterial {
        base_color: Color::srgb(0.12, 0.12, 0.13),
        perceptual_roughness: 0.95,
        ..default()
    });
    commands.spawn((
        Mesh3d(meshes.add(Cuboid::new(span, 0.04, 10.0))),
        MeshMaterial3d(road.clone()),
        Transform::from_xyz(0.0, 0.02, 0.0),
    ));
    commands.spawn((
        Mesh3d(meshes.add(Cuboid::new(10.0, 0.04, span))),
        MeshMaterial3d(road),
        Transform::from_xyz(0.0, 0.02, 0.0),
    ));

    // Footprints used to keep props and dumpsters out of walls.
    let mut obstacles: Vec<(Vec3, Vec3)> = Vec::new();

    // Buildings on a loose grid, with some empty lots.
    for gx in -3i32..=3 {
        for gz in -3i32..=3 {
            if gx == 0 || gz == 0 || rng.chance(0.2) {
                continue;
            }
            let w = rng.range(6.0, 9.0);
            let d = rng.range(6.0, 9.0);
            let h = rng.range(3.0, 14.0);
            let cx = gx as f32 * 17.0 + rng.range(-1.5, 1.5);
            let cz = gz as f32 * 17.0 + rng.range(-1.5, 1.5);
            let color = Color::hsl(rng.range(0.0, 360.0), 0.25, rng.range(0.32, 0.55));
            let center = Vec3::new(cx, h / 2.0, cz);
            let half = Vec3::new(w / 2.0, h / 2.0, d / 2.0);

            commands.spawn((
                Mesh3d(meshes.add(Cuboid::new(w, h, d))),
                MeshMaterial3d(materials.add(color)),
                Transform::from_translation(center),
                Collider { half },
            ));
            obstacles.push((center, half));
        }
    }

    // Dumpsters
    let dumpster_mesh = meshes.add(Cuboid::new(2.2, 1.3, 1.2));
    let dumpster_mat = materials.add(Color::srgb(0.15, 0.4, 0.22));
    for _ in 0..26 {
        let p = free_spot(&mut rng, &obstacles, 1.5);
        let half = Vec3::new(1.1, 0.65, 0.6);
        let center = Vec3::new(p.x, half.y, p.y);
        commands.spawn((
            Mesh3d(dumpster_mesh.clone()),
            MeshMaterial3d(dumpster_mat.clone()),
            Transform::from_translation(center),
            Collider { half },
        ));
        obstacles.push((center, half));
    }

    // Junk to launch
    let cube = meshes.add(Cuboid::new(1.0, 1.0, 1.0));
    for _ in 0..110 {
        let p = free_spot(&mut rng, &obstacles, 1.0);
        let size = rng.range(0.6, 1.3);
        let hue = rng.range(0.0, 360.0);
        let base = Color::hsl(hue, 0.75, 0.55);
        let mat = materials.add(StandardMaterial {
            base_color: base,
            perceptual_roughness: 0.6,
            ..default()
        });
        commands.spawn((
            Mesh3d(cube.clone()),
            MeshMaterial3d(mat),
            Transform::from_xyz(p.x, size * 0.55, p.y)
                .with_rotation(Quat::from_rotation_y(rng.range(0.0, 6.28)))
                .with_scale(Vec3::splat(size)),
            Prop {
                vel: Vec3::ZERO,
                ang: Vec3::ZERO,
                radius: size * 0.55,
                mass: 0.4 + size.powi(3),
                cooldown: 0.0,
                hue,
                base,
            },
        ));
    }

    commands.insert_resource(PickupAssets::create(&mut meshes, &mut materials));
}

pub fn props_physics(
    time: Res<Time>,
    mods: Res<Mods>,
    mut rng: ResMut<Rng>,
    statics: Query<(&Transform, &Collider), Without<Prop>>,
    mut props: Query<(&mut Transform, &mut Prop)>,
) {
    let dt = time.delta_secs().min(0.05);
    for (mut tf, mut prop) in &mut props {
        prop.cooldown = (prop.cooldown - dt).max(0.0);

        let mut pos = tf.translation;
        let mut vel = prop.vel;
        let grounded = pos.y <= prop.radius + 0.02;

        // Giggle Caps: the junk starts hopping around.
        if mods.hallu && grounded && rng.chance(0.6 * dt) {
            vel.y = rng.range(4.0, 8.0);
            prop.ang = Vec3::new(rng.signed(), rng.signed(), rng.signed()) * 4.0;
        }

        vel.y -= 22.0 * dt;
        pos += vel * dt;

        for (stf, col) in &statics {
            resolve_sphere_aabb(&mut pos, &mut vel, prop.radius, stf.translation, col.half, 0.3);
        }

        if pos.y < prop.radius {
            pos.y = prop.radius;
            if vel.y < 0.0 {
                vel.y = if vel.y < -2.0 { -vel.y * 0.3 } else { 0.0 };
            }
            let friction = (1.0 - 2.5 * dt).max(0.0);
            vel.x *= friction;
            vel.z *= friction;
            prop.ang *= (1.0 - 4.0 * dt).max(0.0);
        }

        if pos.x.abs() > MAP_HALF {
            pos.x = pos.x.clamp(-MAP_HALF, MAP_HALF);
            vel.x *= -0.5;
        }
        if pos.z.abs() > MAP_HALF {
            pos.z = pos.z.clamp(-MAP_HALF, MAP_HALF);
            vel.z *= -0.5;
        }

        tf.translation = pos;
        prop.vel = vel;

        if prop.ang.length_squared() > 1e-4 {
            tf.rotation = Quat::from_scaled_axis(prop.ang * dt) * tf.rotation;
        }

        // Settle flat once it stops moving.
        if pos.y <= prop.radius + 0.02 && vel.length() < 2.0 {
            let yaw = tf.rotation.to_euler(EulerRot::YXZ).0;
            let target = Quat::from_rotation_y(yaw);
            tf.rotation = tf.rotation.slerp(target, 1.0 - (-8.0 * dt).exp());
        }
    }
}

pub fn player_prop_collisions(
    mods: Res<Mods>,
    mut run: ResMut<Run>,
    mut rng: ResMut<Rng>,
    mut player_q: Query<(&Transform, &mut Player), Without<Prop>>,
    mut props: Query<(&mut Transform, &mut Prop), Without<Player>>,
) {
    let Ok((ptf, mut player)) = player_q.get_single_mut() else {
        return;
    };
    let ppos = ptf.translation;

    for (mut tf, mut prop) in &mut props {
        let d = tf.translation - ppos;
        let dist = d.length();
        let min_dist = PLAYER_R + prop.radius;
        if dist >= min_dist || dist < 1e-4 {
            continue;
        }
        let n = d / dist;
        tf.translation += n * (min_dist - dist);

        let closing = (player.vel - prop.vel).dot(n);
        if closing > 1.0 {
            let tackling = player.tackle > 0.0;
            let boost = if tackling { 2.5 } else { 1.0 };
            let power = closing * boost * mods.tackle / prop.mass;
            prop.vel += n * power.min(45.0) + Vec3::Y * (2.0 + closing * 0.25);
            prop.ang = Vec3::new(rng.signed(), rng.signed(), rng.signed()) * closing.min(14.0);
            player.vel -= n * closing * 0.1 * prop.mass.min(2.0);

            if prop.cooldown <= 0.0 && run.alive {
                prop.cooldown = 0.5;
                run.chaos(if tackling { 15.0 } else { 5.0 }, mods.score);
            }
        }
    }
}

/// Giggle Caps: the sky and the junk cycle through colors.
pub fn hallucination_visuals(
    time: Res<Time>,
    mods: Res<Mods>,
    mut clear: ResMut<ClearColor>,
    mut materials: ResMut<Assets<StandardMaterial>>,
    props: Query<(&MeshMaterial3d<StandardMaterial>, &Prop)>,
    mut was_active: Local<bool>,
) {
    if mods.hallu {
        let t = time.elapsed_secs();
        clear.0 = Color::hsl((t * 40.0) % 360.0, 0.6, 0.2);
        for (handle, prop) in &props {
            if let Some(m) = materials.get_mut(&handle.0) {
                m.base_color = Color::hsl((t * 90.0 + prop.hue) % 360.0, 0.9, 0.55);
            }
        }
        *was_active = true;
    } else if *was_active {
        clear.0 = sky();
        for (handle, prop) in &props {
            if let Some(m) = materials.get_mut(&handle.0) {
                m.base_color = prop.base;
            }
        }
        *was_active = false;
    }
}
