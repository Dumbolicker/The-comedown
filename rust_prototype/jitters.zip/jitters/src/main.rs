//! JITTERS: a chaos sandbox where your life clock is always running out.
//!
//! Clean-room design: original code, original assets (primitive shapes only),
//! built from the general idea of a "physics-chaos open-world sandbox".

mod hud;
mod pickups;
mod player;
mod state;
mod substances;
mod util;
mod world;

use bevy::prelude::*;

use crate::pickups::Pickup;
use crate::player::{CamRig, Player, PLAYER_R};
use crate::state::{Life, Run, Toast};
use crate::substances::{Effects, Mods};
use crate::util::{sky, Rng};

fn main() {
    let seed = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_nanos() as u64)
        .unwrap_or(0x9E37_79B9_7F4A_7C15);

    App::new()
        .add_plugins(DefaultPlugins.set(WindowPlugin {
            primary_window: Some(Window {
                title: "JITTERS".into(),
                ..default()
            }),
            ..default()
        }))
        .insert_resource(ClearColor(sky()))
        .insert_resource(AmbientLight {
            color: Color::WHITE,
            brightness: 450.0,
            ..default()
        })
        .insert_resource(Rng::new(seed))
        .insert_resource(Toast {
            text: "Your clock is ticking. Find something. Anything.  (WASD move, Space jump, LMB tackle, Q flop)"
                .into(),
            timer: 9.0,
        })
        .init_resource::<Life>()
        .init_resource::<Run>()
        .init_resource::<Effects>()
        .init_resource::<Mods>()
        .init_resource::<CamRig>()
        .add_systems(
            Startup,
            (
                world::setup_world,
                player::spawn_player,
                player::spawn_camera,
                player::grab_cursor,
                hud::setup_hud,
            ),
        )
        .add_systems(
            Update,
            (
                restart,
                substances::tick_effects,
                substances::life_drain,
                player::toggle_cursor,
                player::player_control,
                world::props_physics,
                world::player_prop_collisions,
                pickups::pickups_system,
                pickups::pickup_spawner,
                world::hallucination_visuals,
                player::animate_arms,
                player::camera_follow,
                hud::hud_update,
            )
                .chain(),
        )
        .run();
}

/// Press R after the comedown to go again. The wrecked town stays wrecked.
fn restart(
    keys: Res<ButtonInput<KeyCode>>,
    mut commands: Commands,
    mut run: ResMut<Run>,
    mut life: ResMut<Life>,
    mut effects: ResMut<Effects>,
    mut toast: ResMut<Toast>,
    pickups: Query<Entity, With<Pickup>>,
    mut player: Query<(&mut Transform, &mut Player)>,
) {
    if run.alive || !keys.just_pressed(KeyCode::KeyR) {
        return;
    }

    let best = run.best;
    *run = Run { best, ..default() };
    *life = Life::default();
    *effects = Effects::default();
    toast.say("Round two. Find something. Anything.");

    for e in &pickups {
        commands.entity(e).despawn_recursive();
    }
    if let Ok((mut tf, mut p)) = player.get_single_mut() {
        tf.translation = Vec3::new(2.0, PLAYER_R, 2.0);
        *p = Player::default();
    }
}
