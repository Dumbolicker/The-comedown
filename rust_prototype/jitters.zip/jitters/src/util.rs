use bevy::prelude::*;

/// Half-width of the playable square. The world is MAP_HALF * 2 metres across.
pub const MAP_HALF: f32 = 60.0;

pub fn sky() -> Color {
    Color::srgb(0.53, 0.74, 0.92)
}

/// Tiny xorshift RNG so the project needs no extra crates.
#[derive(Resource)]
pub struct Rng(u64);

impl Rng {
    pub fn new(seed: u64) -> Self {
        Self(seed | 1)
    }

    pub fn next_u32(&mut self) -> u32 {
        let mut x = self.0;
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        self.0 = x;
        (x >> 32) as u32
    }

    /// Uniform in [0, 1].
    pub fn f32(&mut self) -> f32 {
        self.next_u32() as f32 / u32::MAX as f32
    }

    pub fn range(&mut self, lo: f32, hi: f32) -> f32 {
        lo + (hi - lo) * self.f32()
    }

    /// Uniform in [-1, 1].
    pub fn signed(&mut self) -> f32 {
        self.f32() * 2.0 - 1.0
    }

    pub fn chance(&mut self, p: f32) -> bool {
        self.f32() < p
    }

    pub fn index(&mut self, len: usize) -> usize {
        (self.next_u32() as usize) % len.max(1)
    }
}

/// Pushes a sphere out of an axis-aligned box and reflects its velocity.
/// Returns the contact normal if the sphere was touching the box.
pub fn resolve_sphere_aabb(
    pos: &mut Vec3,
    vel: &mut Vec3,
    radius: f32,
    center: Vec3,
    half: Vec3,
    bounce: f32,
) -> Option<Vec3> {
    let min = center - half;
    let max = center + half;
    let closest = pos.clamp(min, max);
    let delta = *pos - closest;
    let dist_sq = delta.length_squared();
    if dist_sq >= radius * radius {
        return None;
    }

    let normal;
    if dist_sq > 1e-8 {
        let dist = dist_sq.sqrt();
        normal = delta / dist;
        *pos += normal * (radius - dist);
    } else {
        // Sphere centre is inside the box: leave through the shallowest face.
        let to_min = *pos - min;
        let to_max = max - *pos;
        let options = [
            (to_max.x + radius, Vec3::X),
            (to_min.x + radius, Vec3::NEG_X),
            (to_max.y + radius, Vec3::Y),
            (to_min.y + radius, Vec3::NEG_Y),
            (to_max.z + radius, Vec3::Z),
            (to_min.z + radius, Vec3::NEG_Z),
        ];
        let mut best = options[0];
        for o in options.iter() {
            if o.0 < best.0 {
                best = *o;
            }
        }
        normal = best.1;
        *pos += normal * best.0;
    }

    let vn = vel.dot(normal);
    if vn < 0.0 {
        *vel -= normal * vn * (1.0 + bounce);
    }
    Some(normal)
}

/// Finds a random (x, z) spot that is not inside any obstacle footprint.
/// Obstacles are (center, half-extents) pairs.
pub fn free_spot(rng: &mut Rng, obstacles: &[(Vec3, Vec3)], margin: f32) -> Vec2 {
    for _ in 0..40 {
        let p = Vec2::new(
            rng.range(-MAP_HALF + 3.0, MAP_HALF - 3.0),
            rng.range(-MAP_HALF + 3.0, MAP_HALF - 3.0),
        );
        let blocked = obstacles
            .iter()
            .any(|o| (p.x - o.0.x).abs() < o.1.x + margin && (p.y - o.0.z).abs() < o.1.z + margin);
        if !blocked {
            return p;
        }
    }
    Vec2::ZERO
}
