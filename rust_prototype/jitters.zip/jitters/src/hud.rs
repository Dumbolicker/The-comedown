use std::f32::consts::TAU;

use bevy::prelude::*;

use crate::pickups::Pickup;
use crate::player::{CamRig, Player};
use crate::state::{Life, Run, Toast};
use crate::substances::{Effects, Substance};

#[derive(Component, Clone, Copy, PartialEq, Eq)]
pub enum HudText {
    Score,
    Effects,
    Toast,
    Stash,
    Center,
}

#[derive(Component)]
pub struct LifeFill;

const DIRS: [&str; 8] = [
    "AHEAD",
    "AHEAD-RIGHT",
    "RIGHT",
    "BEHIND-RIGHT",
    "BEHIND",
    "BEHIND-LEFT",
    "LEFT",
    "AHEAD-LEFT",
];

// The default Bevy font is ASCII-only, so no emoji or fancy arrows here.
pub fn setup_hud(mut commands: Commands) {
    commands
        .spawn(Node {
            width: Val::Percent(100.0),
            height: Val::Percent(100.0),
            flex_direction: FlexDirection::Column,
            justify_content: JustifyContent::SpaceBetween,
            padding: UiRect::all(Val::Px(16.0)),
            ..default()
        })
        .with_children(|root| {
            // Top-left block
            root.spawn(Node {
                flex_direction: FlexDirection::Column,
                row_gap: Val::Px(6.0),
                ..default()
            })
            .with_children(|top| {
                top.spawn((
                    Text::new("LIFE"),
                    TextFont { font_size: 20.0, ..default() },
                    TextColor(Color::WHITE),
                ));
                top.spawn((
                    Node {
                        width: Val::Px(380.0),
                        height: Val::Px(22.0),
                        ..default()
                    },
                    BackgroundColor(Color::srgba(0.0, 0.0, 0.0, 0.55)),
                ))
                .with_children(|bar| {
                    bar.spawn((
                        Node {
                            width: Val::Percent(100.0),
                            height: Val::Percent(100.0),
                            ..default()
                        },
                        BackgroundColor(Color::srgb(0.3, 0.9, 0.4)),
                        LifeFill,
                    ));
                });
                top.spawn((
                    Text::new(""),
                    TextFont { font_size: 22.0, ..default() },
                    TextColor(Color::WHITE),
                    HudText::Score,
                ));
                top.spawn((
                    Text::new(""),
                    TextFont { font_size: 18.0, ..default() },
                    TextColor(Color::srgb(0.95, 0.9, 0.5)),
                    HudText::Effects,
                ));
            });

            // Bottom-center block
            root.spawn(Node {
                flex_direction: FlexDirection::Column,
                align_self: AlignSelf::Center,
                align_items: AlignItems::Center,
                row_gap: Val::Px(6.0),
                ..default()
            })
            .with_children(|bot| {
                bot.spawn((
                    Text::new(""),
                    TextFont { font_size: 22.0, ..default() },
                    TextColor(Color::srgb(1.0, 0.95, 0.7)),
                    HudText::Toast,
                ));
                bot.spawn((
                    Text::new(""),
                    TextFont { font_size: 18.0, ..default() },
                    TextColor(Color::srgb(0.8, 0.9, 1.0)),
                    HudText::Stash,
                ));
            });
        });

    // Game-over overlay
    commands
        .spawn(Node {
            position_type: PositionType::Absolute,
            width: Val::Percent(100.0),
            top: Val::Percent(33.0),
            justify_content: JustifyContent::Center,
            ..default()
        })
        .with_children(|c| {
            c.spawn((
                Text::new(""),
                TextFont { font_size: 44.0, ..default() },
                TextColor(Color::srgb(1.0, 0.35, 0.3)),
                TextLayout {
                    justify: JustifyText::Center,
                    ..default()
                },
                HudText::Center,
            ));
        });
}

pub fn hud_update(
    run: Res<Run>,
    life: Res<Life>,
    effects: Res<Effects>,
    toast: Res<Toast>,
    rig: Res<CamRig>,
    player: Query<&Transform, With<Player>>,
    pickups: Query<&Transform, With<Pickup>>,
    mut texts: Query<(&mut Text, &HudText)>,
    mut fill: Query<(&mut Node, &mut BackgroundColor), With<LifeFill>>,
) {
    // Life bar
    if let Ok((mut node, mut bg)) = fill.get_single_mut() {
        let f = (life.left / life.max).clamp(0.0, 1.0);
        node.width = Val::Percent(f * 100.0);
        bg.0 = if f > 0.4 {
            Color::srgb(0.3, 0.9, 0.4)
        } else if f > 0.2 {
            Color::srgb(0.95, 0.8, 0.2)
        } else {
            Color::srgb(0.95, 0.25, 0.2)
        };
    }

    // Active effects
    let mut lines: Vec<String> = Vec::new();
    for s in Substance::ALL {
        let t = effects.timers[s.idx()];
        if t > 0.0 {
            lines.push(format!("> {}  {:.0}s", s.name(), t));
        }
    }
    if effects.crash > 0.0 {
        lines.push(format!("> COMEDOWN  {:.0}s  (slow, drains faster)", effects.crash));
    }
    let effects_text = lines.join("\n");

    // Nearest stash, relative to where the camera is looking
    let stash = match player.get_single() {
        Ok(ptf) => {
            let mut best: Option<(f32, Vec3)> = None;
            for t in &pickups {
                let d = t.translation - ptf.translation;
                let l = d.length();
                if best.map_or(true, |b| l < b.0) {
                    best = Some((l, d));
                }
            }
            match best {
                Some((l, d)) => {
                    let local = Quat::from_rotation_y(-rig.yaw) * d;
                    let ang = local.x.atan2(-local.z);
                    let idx = ((ang / (TAU / 8.0)).round() as i32).rem_euclid(8) as usize;
                    let roof = if d.y > 2.5 { " (ON A ROOF)" } else { "" };
                    format!("Nearest stash: {:.0}m {}{}", l, DIRS[idx], roof)
                }
                None => "No stash in sight...".to_string(),
            }
        }
        Err(_) => String::new(),
    };

    for (mut text, kind) in &mut texts {
        let s = match kind {
            HudText::Score => format!(
                "SCORE {:.0}   COMBO x{}   TIME {:.0}s   BEST {:.0}",
                run.score, run.combo, run.time, run.best
            ),
            HudText::Effects => effects_text.clone(),
            HudText::Toast => {
                if toast.timer > 0.0 {
                    toast.text.clone()
                } else {
                    String::new()
                }
            }
            HudText::Stash => {
                if run.alive {
                    stash.clone()
                } else {
                    String::new()
                }
            }
            HudText::Center => {
                if run.alive {
                    String::new()
                } else {
                    format!(
                        "THE COMEDOWN CAME\nsurvived {:.0}s   score {:.0}\npress R to go again",
                        run.time, run.score
                    )
                }
            }
        };
        if text.0 != s {
            text.0 = s;
        }
    }
}
